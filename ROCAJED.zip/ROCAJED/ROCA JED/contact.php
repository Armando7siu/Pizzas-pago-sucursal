<!DOCTYPE html>
<html lang="en">

<head>
<?php session_start(); include("conn_db.php"); include('head.php');?>    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/main.css" rel="stylesheet">
    <style>
        html {
            height: 100%;
        }

  h6{
  color: Red !important;

  }

    </style>
    <title>Contactanos | Pizzas Roca Jed</title>
</head>

<body class="d-flex flex-column h-100">
    <?php include('nav_header.php')?>
<!-- Contact Starts -->
<section class="about py-5">
    <div class="container py-md-5">
        <h3 class="tittle-wthree text-center">Contactanos</h3>
        <p class="sub-tittle text-center mt-4 mb-sm-5 mb-4">Estimados usuarios: pueden comunicarse directamente con el/los para cualquier consulta a traves del correo y numero de telefono que se muestran.    </p>
        <div class="row">
            <div class="col-lg-6 contact-info-left">
                <ul class="list-unstyled w3ls-items">
                    <li>
                        <div class="row mt-5">
                            <div class="col-9">

                            <div class="col-9">
                                <h6>Pizzas Roca Jed</h6>
                                <p> No hay mejor triángulo amoroso que una rebanada de Pizza.


    </p>
                            </div>
                        </div>
                    </li>

                    <li>
                        <div class="row mt-5">
                            <div class="col-9">

                            <div class="col-9">
                                <h6>Email</h6>
                                <a href="mailto:luckymaharjan5@gmail.com">ignaciogigimenez@gmail.com</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="row mt-5">
                            <div class="col-9">

                            <div class="col-9">
                            <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
                            <div class="elfsight-app-22dd923a-9a44-429c-bce2-07c16945da64" data-elfsight-app-lazy></div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        

            </div>
        </div>


    </div>
</section>
    <!-- Contact Ends -->


<footer class="text-center text-white">
  <!-- Copyright -->
  <div class="text-center p-2 p-2 mb-1 bg-dark text-white">
    <p class="text-white">Copyright © 2024 Pizzas Roca Jed Todos los derechos reservados.  </p>

  </div>
  <!-- Copyright -->
</footer>
</body>

</html>
