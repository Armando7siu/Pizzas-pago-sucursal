<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    session_start();
    include("../conn_db.php");
    include('../head.php');
    if($_SESSION["utype"]!="ADMIN"){
        header("location: ../restricted.php");
        exit(1);
    }
    if(isset($_POST["btn_add"])){
        $pwd = $_POST["pwd"];
        $cfpwd = $_POST["cfpwd"];
        if($pwd != $cfpwd){
            ?>
        <script>
            alert('La contraseña no coincide.\nPor favor, introduzcala de nuevo.');
            history.back();
        </script>
        <?php
            exit(1);
        }else{
            $username = $_POST["username"];
            $firstname = $_POST["firstname"];
            $lastname = $_POST["lastname"];
            $gender = $_POST["gender"];
            $email = $_POST["email"];
            $type = $_POST["type"];
            if($gender == "-" || $type == "-"){
            ?>
                <script>
                    alert('Aún no has seleccionado tu género o rol.\nPor favor, selecciona nuevamente');
                    history.back();
                </script>
            <?php
                exit(1);
            }
            //Check for duplicating username
            $query = "SELECT c_username FROM customer WHERE c_username = '$username';";
            $result = $mysqli -> query($query);
            if($result -> num_rows >= 1){
                ?>
                <script>
                    alert('¡El nombre de usuario ya está en uso!');
                    history.back();
                </script>
            <?php
            }
            $result -> free_result();
            //Check for duplicating email
            $query = "SELECT c_email FROM customer WHERE c_email = '$email';";
            $result = $mysqli -> query($query);
            if($result -> num_rows >= 1){
            ?>
                <script>
                    alert('¡El correo electrónico ya está en uso!');
                    history.back();
                </script>
            <?php
            }
            $result -> free_result();
            $query = "INSERT INTO customer (c_username,c_pwd,c_firstname,c_lastname,c_email,c_gender,c_type)
            VALUES ('$username','$pwd','$firstname','$lastname','$email','$gender','$type');";
            $result = $mysqli -> query($query);
            if($result){
                header("location: admin_customer_list.php?add_cst=1");
            }else{
                header("location: admin_customer_list.php?add_cst=0");
            }
        }
        exit(1);
    }

    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../css/login.css" rel="stylesheet">
    <title>Agregar nuevo cliente </title>
</head>

<body class="d-flex flex-column">
    <?php include('nav_header_admin.php');?>
    <div class="container mt-4"></div>
    <div class="container form-signin mt-auto">
        <a class="nav nav-item text-decoration-none text-muted" href="#" onclick="history.back();">
            <i class="bi bi-arrow-left-square me-2"></i>Volver
        </a>
        <form method="POST" action="admin_customer_add.php" class="form-floating">
            <h2 class="mt-4 mb-3 fw-normal text-bold"><i class="bi bi-person-plus me-2"></i>Agregar nuevo cliente</h2>
            <div class="form-floating mb-2">
                <input type="text" class="form-control" id="username" placeholder="Username" name="username"
                    minlength="5" maxlength="45" required>
                <label for="username">Nombre de usuario</label>
            </div>
            <div class="form-floating mb-2">
                <input type="password" class="form-control" id="pwd" placeholder="Password" name="pwd" minlength="8"
                    maxlength="45" required>
                <label for="pwd">Contraseña</label>
            </div>
            <div class="form-floating mb-2">
                <input type="password" class="form-control" id="cfpwd" placeholder="Confirm Password" minlength="8"
                    maxlength="45" name="cfpwd" required>
                <label for="cfpwd">Confirmar contraseña</label>
                <div id="passwordHelpBlock" class="form-text smaller-font">
                La contraseña debe tener al menos 8 caracteres.
                </div>
            </div>
            <div class="form-floating mb-2">
                <input type="text" class="form-control" id="firstname" placeholder="First Name" name="firstname"
                    required>
                <label for="firstname">Nombre de pila</label>
            </div>
            <div class="form-floating mb-2">
                <input type="text" class="form-control" id="lastname" placeholder="Last Name" name="lastname" required>
                <label for="lastname">Apellido</label>
            </div>
            <div class="form-floating mb-2">
                <input type="email" class="form-control" id="email" placeholder="E-mail" name="email" required>
                <label for="email">E-mail</label>
            </div>
            <div class="form-floating">
                <select class="form-select mb-2" id="gender" name="gender">
                    <option selected value="-">---</option>
                    <option value="M">Masculino</option>
                    <option value="F">Femenino</option>
                    <option value="N">No binario</option>
                </select>
                <label for="gender"> Género</label>
            </div>
            <div class="form-floating">
                <select class="form-select mb-2" id="type" name="type">
                    <option selected value="-">---</option>
                    <option value="STD">Menores de 15 años</option>
                    <option value="INS">16 Años - 20 Años</option>
                    <option value="TAS">21 Años - 30 Años</option>
                    <option value="STF">31 Años - 40 Años</option>
                    <option value="GUE">41 Años - 50 Años</option>
                    <option value="OTH">Más de 10 años</option>
                </select>
                <label for="gender">Tu Edad</label>
            </div>
            <button class="w-100 btn btn-success mb-3" type="submit" name="btn_add" style="background-color: #FF8C00; border-color: #FF8C00;">Agregar nuevo cliente</button>
            </form>
    </div>
    <div class="container mt-4"></div>
    <footer
        class="footer d-flex flex-wrap justify-content-between align-items-center px-5 py-3 mt-auto bg-secondary text-light">
        <span class="smaller-font">&copy; 2024 Pizzas Roca Jed<br /><span class="xsmall-font">Todos los derechos reservados.</span></span>
        <ul class="nav justify-content-end list-unstyled d-flex">
    <li class="ms-3 d-flex align-items-center">
        <a class="text-light d-flex align-items-center" target="_blank" href="https://www.facebook.com/profile.php?id=877826532319875&_rdr" style="text-decoration: none; color: #f8f9fa;">
            <i class="bi bi-facebook" style="font-size: 2rem; margin-right: 0.5rem;"></i>
            Síguenos en nuestra página de Facebook
        </a>
    </li>
</ul>
    </footer>
</body>

</html>

