<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <?php
        session_start();
        include("../conn_db.php");
        include('../head.php');
        if($_SESSION["utype"]!="ADMIN"){
            header("location: ../restricted.php");
            exit(1);
        }
    ?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../img/ICON_F.png" rel="icon">
    <link href="../css/main.css" rel="stylesheet">
    <title>Lista de menú| </title>
</head>

<body class="d-flex flex-column h-100">

    <?php include('nav_header_admin.php')?>

    <div class="container p-2 pb-0" id="admin-dashboard">
        <div class="mt-4 border-bottom">
            <a class="nav nav-item text-decoration-none text-muted mb-2" href="#" onclick="history.back();">
                <i class="bi bi-arrow-left-square me-2"></i>Volver
            </a>

            <?php
            if(isset($_GET["dsb_fdt"])){
                if($_GET["dsb_fdt"]==1){
                    ?>
            <!-- START SUCCESSFULLY DELETE MENU -->
            <div class="row row-cols-1 notibar">
                <div class="col mt-2 ms-2 p-2 bg-success text-white rounded text-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                        class="bi bi-check-circle ms-2" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path
                            d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                    </svg>
                    <span class="ms-2 mt-2">Menú eliminado exitosamente.</span>
                    <span class="me-2 float-end"><a class="text-decoration-none link-light" href="admin_food_list.php">X</a></span>
                </div>
            </div>
            <!-- END SUCCESSFULLY DELETE MENU -->
            <?php }else{ ?>
            <!-- START FAILED DELETE MENU -->
            <div class="row row-cols-1 notibar">
                <div class="col mt-2 ms-2 p-2 bg-danger text-white rounded text-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                        class="bi bi-x-circle ms-2" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path
                            d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg><span class="ms-2 mt-2">No se pudo eliminar el menú.</span>
                    <span class="me-2 float-end"><a class="text-decoration-none link-light" href="admin_food_list.php">X</a></span>
                </div>
            </div>
            <!-- END FAILED DELETE MENU -->
            <?php }
                }
            if(isset($_GET["add_fdt"])){
                if($_GET["add_fdt"]==1){
                    ?>
            <!-- START SUCCESSFULLY FOOD MENU -->
            <div class="row row-cols-1 notibar">
                <div class="col mt-2 ms-2 p-2 bg-success text-white rounded text-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                        class="bi bi-check-circle ms-2" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path
                            d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                    </svg>
                    <span class="ms-2 mt-2">Se agregó nuevo menú exitosamente.</span>
                    <span class="me-2 float-end"><a class="text-decoration-none link-light" href="admin_food_list.php">X</a></span>
                </div>
            </div>
            <!-- END SUCCESSFULLY FOOD MENU -->
            <?php }else{ ?>
            <!-- START FAILED FOOD MENU -->
            <div class="row row-cols-1 notibar">
                <div class="col mt-2 ms-2 p-2 bg-danger text-white rounded text-start">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                        class="bi bi-x-circle ms-2" viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path
                            d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                    </svg><span class="ms-2 mt-2">Error al agregar nuevo menú.</span>
                    <span class="me-2 float-end"><a class="text-decoration-none link-light" href="admin_food_list.php">X</a></span>
                </div>
            </div>
            <!-- END FAILED FOOD MENU -->
            <?php }
                }
            ?>

            <h2 class="pt-3 display-6">Lista de menú</h2>
            <form class="form-floating mb-3" method="GET" action="admin_food_list.php">
                <div class="row g-2">
                    <div class="col">
                        <input type="text" class="form-control" id="f_name" name="f_name" placeholder="Nombre del menú"
                            <?php if(isset($_GET["search"])){?>value="<?php echo $_GET["f_name"];?>" <?php } ?>>
                    </div>
                    <div class="col">
                        <select class="form-select" id="s_id" name="s_id">
                            <option selected value="">Nombre de sucursal</option>
                            <?php
                                $option_query = "SELECT s_id,s_name FROM shop;";
                                $option_result = $mysqli -> query($option_query);
                                $opt_row = $option_result -> num_rows;
                                if($option_result -> num_rows != 0){
                                    while($option_arr = $option_result -> fetch_array()){
                            ?>
                            <option value="<?php echo $option_arr["s_id"]?>"><?php echo $option_arr["s_name"];?></option>
                            <?php
                                    }
                                }
                            ?>
                        </select>
                    </div>
                    <div class="col-auto">
                        <button type="submit" name="search" value="1" class="btn btn-success">Buscar</button>
                        <button type="reset" class="btn btn-danger"
                            onclick="javascript: window.location='admin_food_list.php'">Limpiar</button>
                        <a href="admin_food_add.php" class="btn btn-primary">Añadir nuevo menú</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="container pt-2" id="cust-table">

        <?php
            if(!isset($_GET["search"])){
                $search_query = "SELECT f.f_id,s.s_id,f.f_name,f.f_price,f.f_todayavail,f.f_preorderavail,s.s_name FROM food f INNER JOIN shop s ON f.s_id = s.s_id ORDER BY f.f_price DESC,f.s_id ASC;";
            }else{
                $search_sid=$_GET["s_id"];
                if($search_sid!=""){$sid_clause = " AND f.s_id = {$search_sid} ";}else{$sid_clause = " ";}
                $search_fn=$_GET["f_name"];
                $search_query = "SELECT f.f_id,s.s_id,f.f_name,f.f_price,f.f_todayavail,f.f_preorderavail,s.s_name FROM food f INNER JOIN shop s ON f.s_id = s.s_id
                WHERE f_name LIKE '%{$search_fn}%'".$sid_clause." ORDER BY f.f_price DESC,f.s_id ASC;";
            }
            $search_result = $mysqli -> query($search_query);
            $search_numrow = $search_result -> num_rows;
            if($search_numrow == 0){
        ?>
        <div class="row">
            <div class="col mt-2 ms-2 p-2 bg-danger text-white rounded text-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                    class="bi bi-x-circle ms-2" viewBox="0 0 16 16">
                    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                    <path
                        d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                </svg><span class="ms-2 mt-2">¡No se encontró ninguna sucursal!</span>
                <a href="admin_food_list.php" class="text-white">Limpiar resultados de busqueda</a>
            </div>
        </div>
        <?php } else{ ?>
        <div class="table-responsive">
        <table class="table rounded-5 table-light table-striped table-hover align-middle caption-top mb-5">
            <caption><?php echo $search_numrow;?> menu(s) <?php if(isset($_GET["search"])){?><br /><a
                    href="admin_food_list.php" class="text-decoration-none text-danger">Limpiar resultados de busqueda</a><?php } ?></caption>
            <thead class="bg-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre del menú</th>
                    <th scope="col">Nombre de sucursal</th>
                    <th scope="col">Precio ($.)</th>
                    <th scope="col">Estado del menú</th>
                    <th scope="col">Accion</th>
                </tr>
            </thead>
            <tbody>
                <?php $i=1; while($row = $search_result -> fetch_array()){ ?>
                <tr>
                    <th><?php echo $i++;?></th>
                    <td><?php echo $row["f_name"];?></td>
                    <td><?php echo $row["s_name"];?></td>
                    <td><?php echo $row["f_price"];?></td>
                    <td>
                    <?php
                        if($row["f_todayavail"]==1){
                        ?>
                        <span class="badge rounded-pill bg-success">Disponible</span>
                        <?php }else{ ?>
                        <span class="badge rounded-pill bg-danger">No disponible</span>
                        <?php }
                            if($row["f_preorderavail"]==1){
                        ?>
                        <span class="badge rounded-pill bg-success">Pre-orden Disponible</span>
                        <?php }else{ ?>
                        <span class="badge rounded-pill bg-danger">Pre-orden No disponible</span>
                        <?php } ?>
                    </td>
                    <td>
                        <a href="admin_food_detail.php?f_id=<?php echo $row["f_id"]?>"
                            class="btn btn-sm btn-primary">Ver</a>
                        <a href="admin_food_edit.php?s_id=<?php echo $row["s_id"];?>&f_id=<?php echo $row["f_id"]?>"
                            class="btn btn-sm btn-outline-success">Editar</a>
                        <a href="admin_food_delete.php?f_id=<?php echo $row["f_id"]?>"
                            class="btn btn-sm btn-outline-danger">Borrar</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>
        <?php }
            $search_result -> free_result();
        ?>
    </div>

    <footer
        class="footer d-flex flex-wrap justify-content-between align-items-center px-5 py- mt-auto bg-secondary text-light">
        <span class="smaller-font">&copy; 2024 Pizzas Roca Jed<br /><span class="xsmall-font">Todos los derechos reservados.</span></span>
        <ul class="nav justify-content-end list-unstyled d-flex">
    <li class="ms-3 d-flex align-items-center">
        <a class="text-light d-flex align-items-center" target="_blank" href="https://www.facebook.com/profile.php?id=877826532319875&_rdr" style="text-decoration: none; color: #f8f9fa;">
            <i class="bi bi-facebook" style="font-size: 2rem; margin-right: 0.5rem;"></i>
            Síguenos en nuestra página de Facebook
        </a>
    </li>
</ul>

</body>

</html>