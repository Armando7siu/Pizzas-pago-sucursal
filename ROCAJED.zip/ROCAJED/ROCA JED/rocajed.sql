-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-08-2024 a las 07:10:22
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `rocajed`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cart`
--

CREATE TABLE `cart` (
  `ct_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `ct_amount` int(11) NOT NULL,
  `ct_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cart`
--

INSERT INTO `cart` (`ct_id`, `c_id`, `s_id`, `f_id`, `ct_amount`, `ct_note`) VALUES
(105, 23, 2, 36, 1, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `customer`
--

CREATE TABLE `customer` (
  `c_id` int(11) NOT NULL,
  `c_username` varchar(45) NOT NULL,
  `c_pwd` varchar(45) NOT NULL,
  `c_firstname` varchar(45) NOT NULL,
  `c_lastname` varchar(45) NOT NULL,
  `c_email` varchar(100) NOT NULL,
  `c_gender` varchar(1) NOT NULL COMMENT 'M for Male, F for Female',
  `c_type` varchar(3) NOT NULL COMMENT 'Type of customer in this canteen (STD for student, INS for instructor, STF for staff, GUE for guest, ADM for admin, OTH for other)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `customer`
--

INSERT INTO `customer` (`c_id`, `c_username`, `c_pwd`, `c_firstname`, `c_lastname`, `c_email`, `c_gender`, `c_type`) VALUES
(2, 'keerthi', 'keerthi', 'keerthi', 'G', 'keerthi@gmail.com', 'F', 'STD'),
(3, 'magesh', '123', 'Magesh', 'K', 'magesh@gmail.com', 'M', 'STD'),
(4, 'ignacio', '12345678', 'IgnacioG', 'Gimenez Ambario', 'ignaciogigimenez@gmail.com', 'M', 'ADM'),
(11, 'selva', '123', 'Selva', 'Narayanan', 'someone@email.com', 'N', 'GUE'),
(16, 'Selvanarayanan', '123', 'Selvanarayanan', 'A', 'selva@gmail.com', 'M', 'STD'),
(19, 'angel', '12345678', 'dharani', 'son', 'angel@gmail.com', 'M', 'GUE'),
(20, 'johndoe', '123', 'John', 'G', 'john@gmail.com', 'F', 'STF'),
(22, 'armando', 'Osopolar0989', 'duarte', 'jose', 'armando13duarte@gmail.com', 'M', 'STD'),
(23, 'anelD', '12345678', 'anel', 'duarte', 'anel4duarte@gmail.com', 'M', 'STF'),
(24, 'antonio', '12345678', 'tony', 'montana', 'tony@gmail.com', 'M', 'GUE'),
(25, 'gokuSAYAN', '12345678', 'son', 'goku', 'goku@gmail.com', 'M', 'STD');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `food`
--

CREATE TABLE `food` (
  `f_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `f_price` decimal(6,2) NOT NULL,
  `f_todayavail` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Food is available to order or not',
  `f_preorderavail` tinyint(4) NOT NULL DEFAULT 1,
  `f_pic` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `food`
--

INSERT INTO `food` (`f_id`, `s_id`, `f_name`, `f_price`, `f_todayavail`, `f_preorderavail`, `f_pic`) VALUES
(12, 2, 'Chicken Biryani', 90.00, 1, 1, '12_2.jpg'),
(13, 2, 'Veg Fried Rice', 65.00, 1, 1, '13_2.jpg'),
(14, 2, 'Paneer Fried Rice', 75.00, 1, 1, '14_2.jpg'),
(15, 2, 'Chicken Noodles', 80.00, 1, 1, '15_2.jpg'),
(19, 2, 'Chappathi', 35.00, 1, 1, '19_2.jfif'),
(20, 2, 'Chicken Fried Rice', 85.00, 1, 1, '20_2.jpg'),
(36, 2, 'Pizza Hawaiana', 225.00, 1, 1, '36_2.jpg'),
(37, 2, 'Pizza Mexicana', 225.00, 1, 1, '37_2.jpg'),
(38, 2, 'Pizza Pepperoni Grande', 250.00, 1, 1, '38_2.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_detail`
--

CREATE TABLE `order_detail` (
  `ord_id` int(11) NOT NULL,
  `orh_id` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `ord_amount` int(11) NOT NULL,
  `ord_buyprice` decimal(6,2) NOT NULL COMMENT 'To keep the snapshot of selected menu cost at the time of the purchase.',
  `ord_note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `order_detail`
--

INSERT INTO `order_detail` (`ord_id`, `orh_id`, `f_id`, `ord_amount`, `ord_buyprice`, `ord_note`) VALUES
(1, 50, 13, 1, 65.00, ''),
(2, 51, 38, 1, 250.00, ''),
(3, 52, 13, 1, 65.00, ''),
(4, 53, 36, 5, 225.00, 'sin piña'),
(5, 54, 37, 6, 225.00, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_header`
--

CREATE TABLE `order_header` (
  `orh_id` int(11) NOT NULL,
  `orh_refcode` varchar(15) DEFAULT NULL,
  `c_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `orh_ordertime` timestamp NOT NULL DEFAULT current_timestamp(),
  `orh_pickuptime` datetime NOT NULL,
  `orh_orderstatus` varchar(10) NOT NULL,
  `orh_finishedtime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `order_header`
--

INSERT INTO `order_header` (`orh_id`, `orh_refcode`, `c_id`, `s_id`, `p_id`, `orh_ordertime`, `orh_pickuptime`, `orh_orderstatus`, `orh_finishedtime`) VALUES
(38, '202201030000038', 11, 2, 36, '2022-01-03 16:14:06', '2022-01-03 17:13:00', 'FNSH', '2024-08-04 00:19:37'),
(41, '202408040000041', 22, 2, 39, '2024-08-03 18:32:36', '2024-08-04 17:03:00', 'FNSH', '2024-08-04 00:19:39'),
(42, '202408050000042', 22, 2, 40, '2024-08-05 23:45:28', '2024-08-05 19:45:00', 'FNSH', '2024-08-05 17:47:55'),
(43, '202408050000043', 22, 2, 41, '2024-08-06 00:24:43', '2024-08-05 18:24:00', 'FNSH', '2024-08-05 20:53:54'),
(44, '202408050000044', 22, 2, 42, '2024-08-06 00:39:21', '2024-08-05 20:38:00', 'FNSH', '2024-08-05 20:53:49'),
(45, '202408050000045', 22, 2, 43, '2024-08-06 01:15:48', '2024-08-05 22:15:00', 'FNSH', '2024-08-05 20:53:45'),
(46, '202408050000046', 22, 2, 44, '2024-08-06 04:44:43', '2024-08-05 22:45:00', 'FNSH', '2024-08-07 16:27:19'),
(47, '202408070000047', 22, 2, 45, '2024-08-07 19:45:21', '2024-08-07 15:01:00', 'FNSH', '2024-08-07 19:40:06'),
(48, '202408070000048', 22, 2, 46, '2024-08-07 21:27:28', '2024-08-07 15:27:00', 'FNSH', '2024-08-07 19:40:08'),
(49, '202408070000049', 22, 2, 47, '2024-08-08 01:31:52', '2024-08-07 20:31:00', 'FNSH', '2024-08-07 19:40:21'),
(50, '202408070000050', 22, 2, 48, '2024-08-08 02:15:12', '2024-08-07 20:15:00', 'FNSH', '2024-08-09 17:18:56'),
(51, '202408090000051', 22, 2, 49, '2024-08-10 00:21:14', '2024-08-09 18:21:00', 'FNSH', '2024-08-09 18:55:35'),
(52, '202408090000052', 22, 2, 50, '2024-08-10 01:16:44', '2024-08-09 19:16:00', 'FNSH', '2024-08-12 22:30:57'),
(53, '202408090000053', 22, 2, 51, '2024-08-10 02:40:46', '2024-08-09 22:00:00', 'FNSH', '2024-08-12 22:31:05'),
(54, '202408120000054', 22, 2, 52, '2024-08-13 04:58:54', '2024-08-12 22:59:00', 'FNSH', '2024-08-12 22:59:14');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payment`
--

CREATE TABLE `payment` (
  `p_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `p_type` varchar(45) NOT NULL,
  `p_amount` decimal(7,2) NOT NULL,
  `p_detail` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `payment`
--

INSERT INTO `payment` (`p_id`, `c_id`, `p_type`, `p_amount`, `p_detail`) VALUES
(23, 19, 'CRDC', 30.00, 'Visa [*4242]'),
(25, 2, 'CRDC', 95.00, 'Visa [*2350]'),
(36, 11, 'CRDC', 90.00, 'Visa [*0403]'),
(38, 3, 'DBTC', 30.00, 'Visa [*6055]'),
(39, 22, 'TRANSFER', 225.00, 'TRANSFER [5448 2475 6789 5768]'),
(40, 22, 'TRANSFER', 225.00, 'TRANSFER [TAMAÑO GRANDE]'),
(41, 22, 'TRANSFER', 225.00, 'TRANSFER [pizza grande]'),
(42, 22, 'TRANSFER', 225.00, 'TRANSFER [tamaño familiar]'),
(43, 22, 'TRANSFER', 140.00, 'TRANSFER [ 5768]'),
(44, 22, 'TRANSFER', 295.00, 'TRANSFER [5865]'),
(45, 22, 'TRANSFER', 250.00, 'TRANSFER [TAMAÑO chica]'),
(46, 22, 'TRANSFER', 250.00, 'TRANSFER [tamaño chica ]'),
(47, 22, 'TRANSFER', 90.00, 'TRANSFER [0764]'),
(48, 22, 'TRANSFER', 65.00, 'TRANSFER [chica]'),
(49, 22, 'TRANSFER', 250.00, 'TRANSFER [10203040]'),
(50, 22, 'Referencia EXTRA', 65.00, 'Referencia EXTRA [TAMAÑO CHICA ]'),
(51, 22, 'Referencia EXTRA', 1125.00, 'Referencia EXTRA [8090]'),
(52, 22, 'Referencia EXTRA', 1350.00, 'Referencia EXTRA [goku]');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `shop`
--

CREATE TABLE `shop` (
  `s_id` int(11) NOT NULL,
  `s_username` varchar(45) NOT NULL,
  `s_pwd` varchar(45) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_location` varchar(100) NOT NULL,
  `s_openhour` time NOT NULL,
  `s_closehour` time NOT NULL,
  `s_status` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Shop ready for taking an order or not (True for open, False for close)',
  `s_preorderStatus` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'Shop is ready for tomorrow pre-order or not',
  `s_email` varchar(100) NOT NULL,
  `s_phoneno` varchar(45) NOT NULL,
  `s_pic` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `shop`
--

INSERT INTO `shop` (`s_id`, `s_username`, `s_pwd`, `s_name`, `s_location`, `s_openhour`, `s_closehour`, `s_status`, `s_preorderStatus`, `s_email`, `s_phoneno`, `s_pic`) VALUES
(2, 'rocajed', '123', 'Pizzas Roca Jed', '129 Miguel Hidalgo OrientePetatlán, Gro. 40850 MX', '15:00:00', '23:30:00', 1, 1, 'ignaciogigimenez@gmail.com', ' 758 107 7957', 'shop2.png');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`ct_id`),
  ADD KEY `fk_ct_c_idx` (`c_id`),
  ADD KEY `fk_ct_s_idx` (`s_id`),
  ADD KEY `fk_ct_f_idx` (`f_id`);

--
-- Indices de la tabla `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`),
  ADD UNIQUE KEY `c_username` (`c_username`),
  ADD UNIQUE KEY `c_email` (`c_email`);

--
-- Indices de la tabla `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `food_shop_s_id_idx` (`s_id`);

--
-- Indices de la tabla `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`ord_id`),
  ADD KEY `fk_orh_ord_idx` (`orh_id`),
  ADD KEY `fk_f_ord_idx` (`f_id`);

--
-- Indices de la tabla `order_header`
--
ALTER TABLE `order_header`
  ADD PRIMARY KEY (`orh_id`),
  ADD KEY `fk_orh_idx` (`c_id`),
  ADD KEY `fk_s_orh_idx` (`s_id`),
  ADD KEY `fk_p_orh_idx` (`p_id`);

--
-- Indices de la tabla `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `p_c_fk_idx` (`c_id`);

--
-- Indices de la tabla `shop`
--
ALTER TABLE `shop`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cart`
--
ALTER TABLE `cart`
  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT de la tabla `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `food`
--
ALTER TABLE `food`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `ord_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `order_header`
--
ALTER TABLE `order_header`
  MODIFY `orh_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT de la tabla `payment`
--
ALTER TABLE `payment`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de la tabla `shop`
--
ALTER TABLE `shop`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_ct_c` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ct_f` FOREIGN KEY (`f_id`) REFERENCES `food` (`f_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ct_s` FOREIGN KEY (`s_id`) REFERENCES `shop` (`s_id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `fk_food_shop_id` FOREIGN KEY (`s_id`) REFERENCES `shop` (`s_id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `fk_f_ord` FOREIGN KEY (`f_id`) REFERENCES `food` (`f_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_orh_ord` FOREIGN KEY (`orh_id`) REFERENCES `order_header` (`orh_id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `order_header`
--
ALTER TABLE `order_header`
  ADD CONSTRAINT `fk_c_orh` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_s_orh` FOREIGN KEY (`s_id`) REFERENCES `shop` (`s_id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `fk_p_c` FOREIGN KEY (`c_id`) REFERENCES `customer` (`c_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
